
1//在 JSON 中编辑 docker-registry.yaml 中的数据，然后使用编辑后的数据创建资源
//kubectl create -f docker.yaml --edit -o json

2//创建名为 “foo” 的集群角色，并指定 API 组
//kubectl create clusterrole foo --verb=get,list,watch --resource=rs.extensions

3//创建名为 “foo” 并指定 SubResource 的集群角色
//kubectl create clusterrole foo --verb=get,list,watch --resource=pods,pods/status

4//根据文件夹 bar 创建名为 my-config 的新配置映射
//kubectl create configmap my-config --from-file=path/to/bar

5//创建 cron 作业
//kubectl create cronjob my-job --image=busybox --schedule="*/1 * * * *"

6//创建一个名为 my-dep 的部署，用于运行 busybox 镜像
//kubectl create deployment my-dep --image=busybox

7//创建一个名为 my-dep 的部署，该部署运行 busybox 镜像并公开端口 5701
//kubectl create deployment my-dep --image=busybox --port=5701

8//创建具有相同主机和多个路径的 Ingress
// kubectl create ingress multipath --class=default \
// --rule="foo.com/=svc:port" \
// --rule="foo.com/admin/=svcadmin:portadmin"


9//创建名为 my-namespace 的新命名空间
//kubectl create namespace my-namespace

10//以 ps 输出格式列出所有 Pod
//kubectl get pods

11//以 JSON 输出格式列出单个 Pod
//kubectl get -o json pod web-pod-13je7

12//以 ps 输出格式列出所有复制控制器和服务
//kubectl get rc,services

13//启动一个 hazelcast pod 并在容器中设置标签 “app=hazelcast” 和 “env=prod”
//kubectl run hazelcast --image=hazelcast/hazelcast --labels="app=hazelcast,env=prod"

14//为复制的 nginx 创建一个服务，该服务在端口 80 上提供服务，并连接到端口 8000 上的容器
//kubectl expose rc nginx --port=80 --target-port=8000

15//使用 pod.json 中指定的类型和名称删除 Pod
//kubectl delete -f ./pod.json

16//删除同名 “baz” 和 “foo” 的 Pod 和服务
//kubectl delete pod,service baz foo

17//以最小的延迟删除 Pod
//kubectl delete pod foo --now

18//更新命名空间中的所有 Pod
//kubectl annotate pods --all description='my frontend running nginx'

19//创建 mypod 的副本，将所有容器镜像更改为 busybox
//kubectl debug mypod --copy-to=my-debugger --set-image=*=busybox

//从 stdin 读取的 Diff 文件
//cat service.yaml | kubectl diff -f -

//编辑名为“docker-registry”的服务
//kubectl edit svc/docker-registry

//更新命名空间中的所有 Pod
//kubectl label pods --all status=unhealthy

//检查我是否可以在任何命名空间中创建 Pod
//kubectl auth can-i create pods --all-namespaces

